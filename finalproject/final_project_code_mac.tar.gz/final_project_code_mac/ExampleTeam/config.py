teamname = 'ExampleTeam'

members = [ ('Gerald Dean Rascoe', 'rascoe@college.harvard.edu'),
            ('Edward May', 'edward@fas.harvard.edu'),
            ('Geraldine Rascoe', 'geraldine@seas.harvard.edu')]
