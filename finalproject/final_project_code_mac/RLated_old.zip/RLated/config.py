teamname = 'RLated'

members = [ ('Zachary Hendlin', 'zgh@mit.edu'),
            ('David Wihl', 'davidwihl@gmail.com')]
